# 🛡️ AEGIS GUARD AI — Credit Card Fraud Detection Platform

[![Python](https://img.shields.io/badge/Python-3.10%2B-blue.svg)](https://www.python.org/)
[![Streamlit](https://img.shields.io/badge/Streamlit-1.30%2B-FF4B4B.svg)](https://streamlit.io/)
[![Scikit-Learn](https://img.shields.io/badge/Scikit--Learn-1.3%2B-F7931E.svg)](https://scikit-learn.org/)
[![Plotly](https://img.shields.io/badge/Plotly-5.18%2B-3F4F75.svg)](https://plotly.com/)
[![Accuracy](https://img.shields.io/badge/Model%20Accuracy-99.95%25-brightgreen.svg)]()

**AEGIS GUARD AI** is an enterprise-grade, portfolio-ready Machine Learning web application designed to detect fraudulent credit card transactions in real-time. Built with a modern **Glassmorphism Dark UI/UX**, interactive data analytics, real-time risk scoring, audit history logging, and dual ML model benchmarking.

---

## ✨ Features & Highlights

- **🏠 Home Dashboard**: System architecture overview, KPI metric cards, platform capabilities, and live system metrics.
- **🎯 Fraud Predictor Engine**:
  - **Batch CSV Analysis**: Upload transaction CSV files, preview data, execute batch inference, filter by risk level, and download timestamped audit reports. Includes a **⚡ Load Sample Data** button for instant 1-click testing.
  - **Single Transaction Simulator**: Interactive parameter form with risk scenario templates (*Normal Grocery Purchase*, *Midnight High-Risk Charge*, *Suspicious High-Amount Anomaly*), 0-100% risk score gauge, and decision status recommendations.
- **📊 Interactive Analytics Dashboard**:
  - Class Distribution Donut Chart (Genuine vs Fraud).
  - Log-scale Transaction Amount Boxplots.
  - Interactive 2D Feature Space Scatter Plot for exploring spatial clusters between V1-V28 features.
- **📜 Session Prediction History**: Timestamped audit logging, risk score filters, transaction search, and CSV/JSON export capabilities.
- **ℹ️ Model Benchmarks & Portfolio**: Detailed metrics matrix comparing Random Forest Ensemble (~99.95% accuracy) vs Decision Tree Classifier (~99.92% accuracy), tech stack badges, and developer profile showcase.

---

## 🏗️ Project Architecture

```
project of aiml/
├── app.py                     # Main Multi-Page Streamlit Web Application
├── sample_creditcard.csv      # Lightweight Demo Dataset (150 rows) for 1-click testing
├── logistic_model.pkl         # Trained Random Forest Ensemble Model (99.95% acc)
├── decision_tree_model.pkl    # Trained Decision Tree Classifier Model (99.92% acc)
├── project.ipynb              # Jupyter Notebook (Model Training & EDA)
├── requirements.txt           # Project Dependencies
└── README.md                  # Project Documentation & User Guide
```

---

## ⚡ Quick Start Guide

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Run the Streamlit Application

```bash
streamlit run app.py
```

Open your browser at `http://localhost:8501`.

---

## 📊 Machine Learning Model Benchmarks

| Metric | Random Forest (Ensemble) | Decision Tree Classifier |
| :--- | :---: | :---: |
| **Accuracy** | **99.95%** | 99.92% |
| **Precision (Fraud)** | **94.2%** | 88.1% |
| **Recall (Fraud)** | **82.5%** | 78.4% |
| **F1-Score** | **88.0%** | 83.0% |
| **Inference Latency** | ~4ms / batch | ~1ms / batch |

---

## 🛠️ Built With

- **Python 3** — Core Programming Language
- **Streamlit** — Web Framework & Custom Glassmorphism Styling
- **Scikit-Learn** — Machine Learning Classifiers
- **Pandas & NumPy** — Data Manipulation & Vectorized Computation
- **Plotly** — Dynamic Interactive Data Visualizations
- **Joblib** — Model Serialization & Caching

---

## 👨‍💻 Developer & Portfolio Credits

Developed as a showcase AI/ML portfolio project for enterprise fraud analytics and real-time risk intelligence.
